﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeToMusic
{
    public partial class Form1 : Form
    {

        string filename;
        string[,] playlist;
        int j;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            this.label1.Text = DateTime.Now.ToString();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            FileDialog open = new OpenFileDialog();
            //wxWindowsMediaplayer1是控件名
            this.axWindowsMediaPlayer1.settings.playCount = 1;//播放次数；
            open.Filter = "*.mp3|*.mp3";
            open.Title = "打开文件";
            if (open.ShowDialog() == DialogResult.OK)
            {
                axWindowsMediaPlayer1.URL = open.FileName;
                axWindowsMediaPlayer1.Ctlcontrols.play();//播放文件
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FileDialog open = new OpenFileDialog();
            //wxWindowsMediaplayer1是控件名
            this.axWindowsMediaPlayer1.settings.playCount = 1;//播放次数
            open.Filter = "*.mp4|*.mp4"; //文件格式
            open.Title = "打开文件";
            if (open.ShowDialog() == DialogResult.OK)
            {
                axWindowsMediaPlayer1.URL = open.FileName;
                axWindowsMediaPlayer1.Ctlcontrols.play();//播放文件
            }
        }
        private void timer1_Tick(object sender, EventArgs e)//定时播放
        {
            this.label1.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            //this.label1.Text = DateTime.Now.ToString("T");
            TimeSpan ts;//时间间隔
            j= dataGridView1.Rows.GetRowCount(DataGridViewElementStates.Visible);
            if (playlist != null)
            {
                for (int i = 0; i < j; i++)
                {
                    if (playlist[i, 1]!=null)//为了保证运行不中断，此步检查非常必要！
                    { 
                        ts = DateTime.Parse(playlist[i, 1]) - DateTime.Now;
                        if (-1 < ts.TotalSeconds && ts.TotalSeconds < 0)//若达到条件则播放文件
                        {
                            axWindowsMediaPlayer1.URL = playlist[i, 0];
                            axWindowsMediaPlayer1.Ctlcontrols.play();//播放文件   
                            dataGridView1.Rows[i].Cells[3].Value = "已播放";
                        }
                        if ( ts.TotalSeconds < -5)
                            dataGridView1.Rows[i].Cells[3].Value = "时间失效";

                    }
                }
            }
            /*-----test
            ts = DateTime.Parse("2020-04-03 14:16:00") - nt;
            TimeSpan jg;
            jg = DateTime.Now - DateTime.Parse("2020-04-03 14:17:00");
            if (-1<ts.TotalSeconds&& ts.TotalSeconds < 0)
            {
                axWindowsMediaPlayer1.URL = "C:\\Users\\xx\\Desktop\\177 - 巴赫平均律.mp3";
                axWindowsMediaPlayer1.Ctlcontrols.play();//播放文件     
            }
            if (-1 < jg.TotalSeconds && jg.TotalSeconds < 0)
            {
                axWindowsMediaPlayer1.URL = "C:\\Users\\xx\\Desktop\\177 - 巴赫平均律.mp3";
                axWindowsMediaPlayer1.Ctlcontrols.play();//播放文件                
            }
            //------------test_end
            */
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.BackgroundColor = Color.White;
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (filename == null || textBox2.Text == null)
                MessageBox.Show("选择文件与播放时间均不能为空！");
            else
            {
                try
                {
                    DateTime.Parse(textBox2.Text);
                    //MessageBox.Show(DateTime.Parse(textBox2.Text).ToString());
                    DataGridViewRow row = new DataGridViewRow();
                    int index = dataGridView1.Rows.Add(row);
                    dataGridView1.Rows[index].Cells[0].Value = index + 1;
                    dataGridView1.Rows[index].Cells[1].Value = filename;
                    dataGridView1.Rows[index].Cells[2].Value = textBox2.Text;
                }
                catch (FormatException ex)
                {
                    MessageBox.Show("不是正确的时间格式。例如：八点三十分应该写成：8:30或8:30:00或08:30:00");
                }
               
            }           

        }

        private void button4_Click(object sender, EventArgs e)//opn file
        {
            FileDialog open = new OpenFileDialog();
            //wxWindowsMediaplayer1是控件名

            axWindowsMediaPlayer1.settings.playCount = 1;//播放次数；
            open.Filter = "*.mp3|*.mp3";
            open.Title = "打开文件";
            if (open.ShowDialog() == DialogResult.OK)
            {
                filename = open.FileName;
                textBox1.Text = filename;
            }
        }
        private void button5_Click(object sender, EventArgs e)//deldete row删除选中行
        {
            if (this.dataGridView1.SelectedRows.Count > 0)
            {
                dataGridView1.Rows.Remove(dataGridView1.SelectedRows[0]);
            }
        }

        private void button6_Click(object sender, EventArgs e)//开始执行按钮
        {
            int number = dataGridView1.Rows.GetRowCount(DataGridViewElementStates.Visible);
            MessageBox.Show("开始执行"+(number-1).ToString()+"条记录。");
            playlist = new string[number+1, 2];
            for (int i=0; i < number; i++)
            {
                if (dataGridView1.Rows[i].Cells[1].Value != null && dataGridView1.Rows[i].Cells[2].Value != null)
                {
                    playlist[i,0]=dataGridView1.Rows[i].Cells[1].Value.ToString();//存放文件路径
                    playlist[i,1] = dataGridView1.Rows[i].Cells[2].Value.ToString();//存放播放时间                
                }
            }
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }
    }
}
